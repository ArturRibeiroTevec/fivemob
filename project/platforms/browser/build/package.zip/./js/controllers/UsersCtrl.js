'use strict';

FivemobControllers

.controller('UsersCtrl', function(API, $state, $scope, $stateParams, $timeout, ionicMaterialMotion, ionicMaterialInk, $ionicPopup) {
    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.isExpanded = false;
    $scope.$parent.setExpanded(false);
    // $scope.$parent.setHeaderFab('right');

    /**
     * USERS ARRAY
     * @type {Array}
     */
    $scope.loading_users = false;
    $scope.users = [];
    $scope.page = 1;

    // Activate ink for controller
    ionicMaterialInk.displayEffect();

    /**
     * ON CLICK: FAB-USERS
     * @param  {[type]} )     {                   $scope.openNewUserModal();    } [description]
     * @param  {[type]} false [description]
     * @return {[type]}       [description]
     */
    document.getElementById('fab-users').addEventListener('click', function () {
        $scope.addNewUser();
    }, false);

    /**
     * ADD NEW USER
     */
    $scope.addNewUser = function () {
        $state.go('app.newuser');
    };

    /**
     * BEFORE ENTER
     */
    $scope.$on('$ionicView.beforeEnter', function () {
        $scope.users = [];
        $scope.page = 1;
        $scope.loading_users = true;
        $scope.$evalAsync();

        $scope.showLoading('Carregando usuários...');

        var getUsers = API.getUsers($scope.page);

        // success
        getUsers.success(function (data) {
            if (data.status === '1') {
                for (var i = 0; i < data.users.length; i++) {
                    $scope.users.push(data.users[i]);
                }

                $scope.hideLoading();
                $scope.loading_users = false;
                $scope.$evalAsync();
                $scope.page += 1;

                $timeout(function() {
                    ionicMaterialMotion.fadeSlideIn({
                        selector: '.animate-fade-slide-in .item',
                    });
                });
            }
            else {
                $scope.hideLoading();
                $scope.showAlert('Falha', data.message);
            }
        });

        // error
        getUsers.error(function () {
            $scope.hideLoading();
            $scope.loading_users = false;
            $scope.showDefaultConnectionError();
            $scope.$evalAsync();
        });
    });

    /**
     * DELETE USER
     * @return {[type]} [description]
     */
    $scope.deleteUser = function (index) {
        $ionicPopup.show({
            title: 'Remover',
            template: "Deseja realmente deletar este usuário?",
            buttons: [
                {
                    text: "Não",
                    onTap: function () {
                        return false;
                    }
                },
                {
                    text: "<strong>Sim</strong>",
                    type: "button-assertive",
                    onTap: function () {
                        return true;
                    }
                }
            ]
        }).then(function (response) {
            if (response) {
                $scope.showLoading('Deletando...');

                var user = $scope.users[index];

                var removeUser = API.removeUser(user);

                /////////////
                // SUCCESS //
                /////////////
                removeUser.success(function (data) {
                    if (data.status == '1') {
                        // remove from array
                        $scope.users.splice(index, 1);

                        $scope.hideLoading();
                        $scope.$digest();
                    }
                    else {
                        $scope.hideLoading();
                        $scope.showAlert('Falha', data.message);
                    }
                });

                ///////////
                // ERROR //
                ///////////
                removeUser.error(function () {
                    $scope.hideLoading();
                    $scope.showDefaultConnectionError();
                });
            }
        });
    };

    /**
     * EDIT USER
     * @param  {[type]} index [description]
     * @return {[type]}       [description]
     */
    $scope.editUser = function (index) {
        Storage.setObject('editUser', $scope.users[index]);
        $state.go('app.newuser');
    };
});



/**
 * NEW USER
 */
FivemobControllers

.controller('NewUserCtrl', function (API, $state, $scope, $stateParams, $timeout, ionicMaterialMotion, ionicMaterialInk, $cordovaActionSheet, $cordovaImagePicker, $cordovaCamera, $window, $ionicPopup) {

    $scope.$parent.showHeader();
    $scope.$parent.clearFabs();
    $scope.isExpanded = false;
    $scope.$parent.setExpanded(false);
    $scope.$parent.setHeaderFab('right');
    $scope.image_item_size = 'auto';
    $scope.image_item_inner_size = 'auto';

    $timeout(function() {
        ionicMaterialMotion.fadeSlideIn({
            selector: '.animate-fade-slide-in .item'
        });
    }, 200);

    // Activate ink for controller
    ionicMaterialInk.displayEffect();

    /**
     * ON CLICK: FAB-USERS
     * @param  {[type]} )     {                   $scope.openNewUserModal();    } [description]
     * @param  {[type]} false [description]
     * @return {[type]}       [description]
     */
    document.getElementById('fab-new-user').addEventListener('click', function () {
        $scope.verifyUser();
    }, false);

    /**
     * NEW USER FORM
     * @type {Object}
     */
    $scope.newUserForm = {
        client: {
            name: '',
            email: '',
            phone: '',
            hide: false,
        },
        images: [],
        realtors: [],
        user: {
            title: '',
            description: '',
            street: '',
            number: '',
            complement: '',
            neighborhood: '',
            city: '',
            state: '',
            zipcode: '',
            format: '',
            type: '',
            m_util: '0.00',
            m_total: '0.00',
            bedrooms: 0,
            rooms: 0,
            kitchens: 0,
            bathrooms: 0,
            suites: 0,
            vacancies: 0,
            washbasins: 0,
            services_areas: 0,
            housekeepers: 0,
            offices: 0,
            grills: 0,
            backyards: 0,
            closets: 0,
            furnitures: 0,
            edicules: 0,
        },
        values: {
            rental_value: '0.00',
            sale_value: '0.00',
            iptu_value: '0.00',
        },
        near: {
            subway: false,
            schools: false,
            bus_stations: false,
            hospitals: false,
            markets: false,
            backeries: false,
            airports: false,
            roads: false,
            shoppings: false,
        },
        condominium: {
            name: '',
            recreation_area: false,
            party_room: false,
            sport_court: false,
            gym: false,
            concierge: false,
            steam_room: false,
            garden: false,
            laundry: false,
            balcony: false,
            pool: false,
            gourmet: false,
            cold_floor: false,
            laminate_floor: false,
            porcelain_floor: false,
            wood_floor: false,
            large_airy: false,
            great_location: false,
            big_comfy: false,
            new: false,
            good_lighting: false,
        },
        publish: {
            imovelweb: false,
            olx: false,
            zapimoveis: false,
            vivareal: false,
        },
    };

    // verify edit user
    var editUser = Storage.getObject('editUser', {});
    $scope.id_user = '';
    if (getObjectLength(editUser) > 0) {
        Storage.setObject('editUser', {});
        $scope.newUserForm = editUser;
        $scope.id_user = editUser.id_user;
        $scope.$evalAsync();
    }
    else {
        $scope.id_user = '';
    }

    $scope.required = {
        client: [
            'name',
            'email',
        ],
        user: [
            'title',
            'description',
            'street',
            'number',
            'neighborhood',
            'city',
            'state',
            'zipcode',
            'format',
            'type',
            'm_util',
            'm_total',
        ],
        values: [
            'rental_value',
            'sale_value',
            'iptu_value',
        ],
        condominium: [
            'name',
        ],
    };

    /**
     * VERIFY USER
     * @return {[type]} [description]
     */
    $scope.verifyUser = function () {
        $scope.showLoading('Verificando dados...');

        // 1) verify required fields
        var array_empties = [];
        for (var group in $scope.required) {
            for (var i = 0; i < $scope.required[group].length; i++) {
                var field = $scope.required[group][i];

                // verify if field was fill
                if ($scope.newUserForm[group][field] === null || $scope.newUserForm[group][field] === '' || !$scope.newUserForm[group][field] || $scope.newUserForm[group][field] == ' ') {
                    // if not, add name on array empties
                    array_empties.push(group + '-' + field);
                }
            }
        }

        if (array_empties.length > 0) {
            $scope.hideLoading();
            $scope.showAlert('Falha', 'Ops! Por favor, preencha os campos requeridos.');

            for (var i = 0; i < array_empties.length; i++) {
                var className = array_empties[i];
                // console.log('CLASS NAME: ' + className);
                document.querySelector('.field-' + className).className += " danger-input";
            }
        }
        else {
            // OK, SAVE
            $scope.showLoading('Salvando...');
            
            var saveUser = API.saveUser($scope.newUserForm, $scope.id_user);

            /////////////
            // SUCCESS //
            /////////////
            saveUser.success(function (data) {
                if (data.status == '1') {
                    $scope.hideLoading();
                    $scope.showAlert('<b>Sucesso</b>', 'Usuário adicionado com sucesso!', function () {
                        $state.go('app.users');

                        $scope.cleanForm();
                    });
                }
                else {
                    $scope.hideLoading();
                    $scope.showAlert('Falha', data.message);
                }
            });

            ///////////
            // ERROR //
            ///////////
            saveUser.error(function () {
                $scope.hideLoading();
                $scope.showDefaultConnectionError();
            });
        }
    };

    /**
     * CLEAN FORM
     * @return {[type]} [description]
     */
    $scope.cleanForm = function () {
        /**
         * NEW USER FORM
         * @type {Object}
         */
        $scope.newUserForm = {
            client: {
                name: '',
                email: '',
                phone: '',
                hide: false,
            },
            images: [],
            realtors: [],
            user: {
                title: '',
                description: '',
                street: '',
                number: '',
                complement: '',
                neighborhood: '',
                city: '',
                state: '',
                zipcode: '',
                format: '',
                type: '',
                m_util: '0.00',
                m_total: '0.00',
                bedrooms: 0,
                rooms: 0,
                kitchens: 0,
                bathrooms: 0,
                suites: 0,
                vacancies: 0,
                washbasins: 0,
                services_areas: 0,
                housekeepers: 0,
                offices: 0,
                grills: 0,
                backyards: 0,
                closets: 0,
                furnitures: 0,
                edicules: 0,
            },
            values: {
                rental_value: '0.00',
                sale_value: '0.00',
                iptu_value: '0.00',
            },
            near: {
                subway: false,
                schools: false,
                bus_stations: false,
                hospitals: false,
                markets: false,
                backeries: false,
                airports: false,
                roads: false,
                shoppings: false,
            },
            condominium: {
                name: '',
                recreation_area: false,
                party_room: false,
                sport_court: false,
                gym: false,
                concierge: false,
                steam_room: false,
                garden: false,
                laundry: false,
                balcony: false,
                pool: false,
                gourmet: false,
                cold_floor: false,
                laminate_floor: false,
                porcelain_floor: false,
                wood_floor: false,
                large_airy: false,
                great_location: false,
                big_comfy: false,
                new: false,
                good_lighting: false,
            },
            publish: {
                imovelweb: false,
                olx: false,
                zapimoveis: false,
                vivareal: false,
            },
        };
    };
});